<template>
  <div
    id="page"
    class="relative min-h-screen bg-black/95 pt-14 transition-all duration-200"
    bis_skin_checked="1"
  >
    <!--[--><!--[--><!--[--><!----><!--]-->
    <div class="relative h-[36rem] overflow-hidden" bis_skin_checked="1">
      <div
        class="z-1 relative flex items-center px-10 pt-40 text-white"
        bis_skin_checked="1"
      >
        <div class="mr-10 flex-1" bis_skin_checked="1">
          <div class="mb-5 text-6xl font-bold opacity-90" bis_skin_checked="1">
            E-learing Revolution 2
          </div>
          <div class="mb-5 text-xl" bis_skin_checked="1">
            We have worked to digitize our school, ang give the whole world the
            opportunity to do it with a new study platform designed for teachers
          </div>
          <a
            href="/courses"
            class="inline-block cursor-pointer rounded-md bg-black px-4 py-3"
          >
            Go to Marketplace
          </a>
          <div bis_skin_checked="1">
            <div bis_skin_checked="1">Hello</div>
            <div bis_skin_checked="1">en</div>
            <div bis_skin_checked="1">it</div>
          </div>
        </div>
        <div class="h-80 flex-1 rounded bg-black" bis_skin_checked="1"></div>
      </div>
    </div>
    <!--]--><!--]-->
  </div>
</template>
